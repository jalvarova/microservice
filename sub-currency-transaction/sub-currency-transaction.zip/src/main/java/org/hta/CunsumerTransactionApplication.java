package org.hta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CunsumerTransactionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CunsumerTransactionApplication.class, args);
	}

}
